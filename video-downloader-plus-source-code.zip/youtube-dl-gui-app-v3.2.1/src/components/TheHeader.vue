<template>
  <header class="app-shell-header">
    <div class="app-menubar" role="menubar" aria-label="Application menu">
      <details class="app-menu">
        <summary>File</summary>
        <div class="app-menu-popover">
          <button type="button" @click="pasteLink">Paste Link</button>
          <button type="button" @click="triggerImport">Import links from file…</button>
        </div>
      </details>
      <details class="app-menu">
        <summary>Edit</summary>
        <div class="app-menu-popover">
          <button type="button" @click="showLinkInput = true; focusLinkInput()">Paste or type a link…</button>
          <button type="button" @click="watchClipboardStore.toggle()">{{ watchClipboardStore.isActive ? 'Turn Smart Mode off' : 'Turn Smart Mode on' }}</button>
        </div>
      </details>
      <details class="app-menu">
        <summary>View</summary>
        <div class="app-menu-popover">
          <button type="button" @click="router.push({ name: 'home' })">Downloads</button>
          <button type="button" @click="router.push({ name: 'settings.downloads' })">Settings</button>
        </div>
      </details>
      <details class="app-menu">
        <summary>Tools</summary>
        <div class="app-menu-popover">
          <button type="button" @click="openInputFilters">Link filters</button>
          <button type="button" @click="triggerImport">Import URL list…</button>
        </div>
      </details>
      <details class="app-menu">
        <summary>Help</summary>
        <div class="app-menu-popover">
          <button type="button" @click="router.push({ name: 'settings.about' })">About Video Downloader Plus</button>
        </div>
      </details>
      <span class="app-menu-product">Video Downloader Plus</span>
    </div>

    <div class="app-toolbar">
      <input
        ref="fileInput"
        type="file"
        accept=".csv,.txt,text/csv,text/plain"
        class="hidden"
        @change="handleFileSelection"
      />
      <button class="app-paste-button" type="button" @click="pasteLink">
        <link-icon class="w-4 h-4" />
        <span>Paste Link</span>
      </button>

      <button
        class="app-smart-toggle"
        type="button"
        role="switch"
        :aria-checked="watchClipboardStore.isActive"
        @click="watchClipboardStore.toggle()"
      >
        <span class="app-switch-track" :class="{ active: watchClipboardStore.isActive }"><i /></span>
        <span class="app-smart-copy">Enable Smart Mode to download links in one click</span>
      </button>

      <form v-if="showLinkInput" @submit.prevent="handleSubmit" class="app-inline-link" autocomplete="off">
        <input
          v-model="url"
          id="queue-url-input"
          name="URL input to queue a video or playlist"
          class="input input-sm"
          :placeholder="inputPlaceholder"
          type="text"
          inputmode="url"
          autocomplete="off"
          autocorrect="off"
          autocapitalize="off"
          spellcheck="false"
          ref="input"
        />
        <button class="app-inline-add" type="submit" :disabled="isInputDisabled">Add</button>
      </form>

      <span class="app-toolbar-spacer" />
      <router-link class="app-settings-button" :title="t('layout.header.nav.settings')" :to="{ name: 'settings.downloads' }">
        <span class="sr-only">{{ t('layout.header.nav.settings') }}</span>
        <cog8-tooth-icon class="w-5 h-5" />
      </router-link>
    </div>
  </header>
</template>

<script setup lang="ts">
import { Cog8ToothIcon, LinkIcon } from '@heroicons/vue/24/outline';
import { ref, computed, onMounted, watch, nextTick } from 'vue';
import { readText } from '@tauri-apps/plugin-clipboard-manager';
import { useClipboard } from '../composables/useClipboard';
import { useRouter } from 'vue-router';
import { useI18n } from 'vue-i18n';
import { useSettingsStore } from '../stores/settings';
import { useMediaStore } from '../stores/media/media';
import { isValidUrl } from '../helpers/url.ts';
import { useWatchClipboardStore } from '../stores/watchClipboard.ts';
import { useToastStore } from '../stores/toast.ts';
import { getUrlImportReadErrorToast, getUrlImportToast, isSupportedImportFile, parseUrlFileText, parseUrlInputText } from '../helpers/urlImport.ts';

const { t } = useI18n();
const router = useRouter();
const mediaStore = useMediaStore();
const toastStore = useToastStore();
const settingsStore = useSettingsStore();
const watchClipboardStore = useWatchClipboardStore();
const doPolling = computed(() => settingsStore.settings.input.autoFillClipboard || watchClipboardStore.isActive);
const { content: clipboardContent, poll } = useClipboard({ doPolling });
const input = ref<HTMLInputElement | null>(null);
const fileInput = ref<HTMLInputElement | null>(null);
const fileImportImmediateDownload = ref(false);
const showLinkInput = ref(false);
const url = ref('');

const inputPlaceholder = computed(() => {
  if (watchClipboardStore.isActive) return t('layout.header.watchClipboardPlaceholder');
  if (clipboardHasValidUrl.value) return clipboardContent.value ?? t('layout.header.placeholder');
  return t('layout.header.placeholder');
});
const clipboardHasValidUrl = computed(() => isValidUrl(clipboardContent.value ?? ''));
const isInputDisabled = computed(() => url.value.length === 0 && !clipboardHasValidUrl.value);

function focusLinkInput() {
  void nextTick(() => input.value?.focus());
}

function addFromInput(immediateDownload = true) {
  const urlToSubmit = url.value.length > 0 ? url.value : clipboardContent.value;
  if (!urlToSubmit) {
    showLinkInput.value = true;
    focusLinkInput();
    return;
  }
  void processParsedUrls(parseUrlInputText(urlToSubmit), immediateDownload, true);
  void router.push('/');
  url.value = '';
  showLinkInput.value = false;
}

async function processParsedUrls(result: { urls: string[]; skipped: number }, immediateDownload = false, fromInput = false) {
  if (result.urls.length > 0) {
    if (immediateDownload) await mediaStore.addUrlBatchAndDownload(result.urls, false, true);
    else await mediaStore.addUrlBatch(result.urls);
  }
  if (!fromInput || result.urls.length > 1) {
    const toast = getUrlImportToast(result);
    toastStore.showToast(toast.message, { style: toast.style });
  }
}

async function pasteLink() {
  try {
    const text = await readText();
    const parsed = parseUrlInputText(text ?? '');
    if (parsed.urls.length > 0) {
      await processParsedUrls(parsed, true);
      void router.push('/');
      return;
    }
  } catch (error) {
    console.debug('Clipboard has no readable URL:', error);
  }
  showLinkInput.value = true;
  focusLinkInput();
}

function handleSubmit() { addFromInput(); }
function triggerImport() {
  fileImportImmediateDownload.value = true;
  fileInput.value?.click();
}
function openInputFilters() { void router.push({ name: 'input-filters' }); }

async function handleFileSelection(event: Event) {
  const target = event.target as HTMLInputElement;
  const file = target.files?.[0];
  target.value = '';
  if (!file || !isSupportedImportFile(file)) {
    const toast = getUrlImportToast({ urls: [], skipped: 0 });
    toastStore.showToast(toast.message, { style: toast.style });
    return;
  }
  try {
    await processParsedUrls(parseUrlFileText(await file.text()), fileImportImmediateDownload.value);
  } catch {
    const toast = getUrlImportReadErrorToast();
    toastStore.showToast(toast.message, { style: toast.style });
  } finally {
    fileImportImmediateDownload.value = false;
  }
}

onMounted(() => input.value?.focus());
watch(clipboardContent, (value) => {
  if (!value) return;
  if (watchClipboardStore.isActive && isValidUrl(value) && !watchClipboardStore.hasSeen(value)) {
    watchClipboardStore.markSeen(value);
    void mediaStore.addAndDownload(value).catch((error) => {
      console.error('Smart Mode could not start the download:', error);
    });
  }
});
watch(() => watchClipboardStore.isActive, (isActive) => {
  if (!isActive) return;
  poll();
  const currentClipboard = clipboardContent.value;
  if (currentClipboard && isValidUrl(currentClipboard) && !watchClipboardStore.hasSeen(currentClipboard)) {
    watchClipboardStore.markSeen(currentClipboard);
    void mediaStore.addAndDownload(currentClipboard).catch((error) => {
      console.error('Smart Mode could not start the download:', error);
    });
  }
});
</script>

use serde::Deserialize;
use std::collections::HashMap;

#[derive(Debug, Deserialize)]
pub struct YtdlpInfo {
  pub id: Option<String>,
  pub title: Option<String>,
  pub uploader: Option<String>,
  pub uploader_id: Option<String>,
  pub duration: Option<f64>,
  pub like_count: Option<i64>,
  pub dislike_count: Option<i64>,
  pub average_rating: Option<f64>,
  pub view_count: Option<i64>,
  pub comment_count: Option<i64>,
  pub description: Option<String>,
  pub extractor_key: Option<String>,
  pub thumbnail: Option<String>,
  pub thumbnails: Option<Vec<YtdlpThumbnail>>,
  pub formats: Option<Vec<YtdlpFormat>>,
  pub subtitles: Option<HashMap<String, Vec<YtdlpSubtitle>>>,
  pub automatic_captions: Option<HashMap<String, Vec<YtdlpSubtitle>>>,
  #[serde(rename = "type_")]
  pub type_: Option<String>,
  pub is_live: Option<bool>,
  pub entries: Option<Vec<YtdlpEntry>>,
  pub webpage_url: Option<String>,
  pub filesize: Option<i64>,
  pub filesize_approx: Option<i64>,
  pub playlist_count: Option<i64>,
  pub chapters: Option<Vec<YtdlpChapter>>,
}

#[derive(Debug, Deserialize)]
pub struct YtdlpThumbnail {
  pub url: Option<String>,
  pub width: Option<i32>,
  pub height: Option<i32>,
}

#[derive(Debug, Deserialize)]
pub struct YtdlpEntry {
  pub url: Option<String>,
  pub webpage_url: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct YtdlpFormat {
  pub format_id: Option<String>,
  pub format: Option<String>,
  pub format_note: Option<String>,
  pub height: Option<i64>,
  pub fps: Option<f64>,
  pub abr: Option<f64>,
  pub audio_channels: Option<f64>,
  pub language: Option<String>,
  pub language_preference: Option<i64>,
  pub ext: Option<String>,
  pub vcodec: Option<String>,
  pub acodec: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct YtdlpSubtitle {
  pub ext: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct YtdlpChapter {
  pub title: Option<String>,
  pub start_time: Option<f64>,
  pub end_time: Option<f64>,
}
